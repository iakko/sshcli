"""Compatibility proxy for the legacy import path."""

from sshcore.models import HostBlock

__all__ = ["HostBlock"]
